<?php 
	$test="test44444";
	echo "$test";
 ?>