/**
* main Module
*
* Description
*/
angular.module('main', ['ngRoute','controllers','services'])
	.config(['$routeProvider',function($routeProvider) {
		$routeProvider
			.when('/v1/schemas',{
				templateUrl:'template/addTpl.html',
				controller:'addTpl'
			})
			.when('/v1/properties',{
				templateUrl:'template/properties.html',
				controller:'addProperties'
			})
			.when('/v1/detail',{
				templateUrl:"template/detail.html",
				controller:"detail"
			})
			.otherwise({
				redirectTo:'/v1/schemas'
			})
	}])
