/**
* control Module
*
* Description
*/

angular.module('controllers', [])
	.controller('addTpl', ['$scope','$http','tpl',function($scope,$http,tpl){
		//获取数据
		// alert(message)
		// console.log(tpl.data.name)
		$scope.data=tpl.data;
		$scope.tplProperties=tpl.properties;
		$scope.edit=function(evt){
			console.log($(evt.target).html())
			$http.get("getTpl.php").success(function(data){
			tpl.data=data;
			// $scope.tplData=data;
			})
			console.log(tpl.data);
			alert(tpl.data)	
		}
		$(window).bind("keydown",function(event){
			if(event.keyCode==27){
				$(".bg").addClass("hidden");
				$(".bg").removeClass("show");
			}
		})
		$scope.close=function(){
			$(".bg").addClass("hidden");
			$(".bg").removeClass("show");
		}
		$scope.addTpl=function(evt){
			// alert("33") 	
			$(".bg").removeClass("hidden");
			$(".bg").addClass("show");
		}
		$scope.tplInfo=function(){
				this.id="",
				this.name="",
				this.displayName="",
				this.type=function(){
					this.id=""
				},
				this.viewWidget=function(){
					this.id="",
					this.customized={}
				},
				this.editWidget=function(){
					this.id="",
					this.customized={}
				},
				this.listWidget=function(){
					this.id="",
					this.customized={}
				},
				this.properties=[]
			}
		$scope.propertie=function(){
				this.id="",
				this.name="",
				this.displayName="",
				this.value="",
				this.type=function(){
					this.id=""
				},
				this.viewWidget=function(){
					this.id="",
					this.customized={}
				},
				this.editWidget=function(){
					this.id="",
					this.customized={}
				},
				this.listWidget=function(){
					this.id="",
					this.customized={}
				}
			}
		$scope.save=function(){
			// 定义新模板
			var tplInfo=new $scope.tplInfo;
			// var tplInfo={
			// 	"id": 1,
	  //       	"name": "",
	  //       	"displayName": "",
	  //       	"viewWidget": {
	  //       	 	"id": "",
	  //       	 	"customized": { }
	  //       	},
	  //       	"editWidget": {
	  //       	 	"id": "",
	  //       	 	"customized": { }
	  //       	},
	  //       	"listWidget": {
	  //       	 	"id": "",
	  //       	 	"customized": { }
	  //       	},
	  //       	"properties":[]
			// }
			
			// var propertie={
			//   "id": "",
	  //         "name": "",
	  //         "displayName": "",
	  //         "type": {
	  //            "id": ""
	  //         },
	  //         "viewWidget": {
	  //           "id": "",
	  //           "customized": { }
	  //         },
	  //         "editWidget": {
	  //           "id": "",
	  //           "customized": { }
	  //         },
	  //         "listWidget": {
	  //           "id": "",
	  //           "customized": { }
	  //         }
			// };

			// 1.模板名称
				tplInfo.name=$($("#tplName")).val();
			// 2.模板属性名
				for(var i=0;i<$("input:checked").length;i++){
					var propertie=new $scope.propertie;
					propertie.name=$($("input:checked")[i]).val();
					// console.log(propertie);
					tplInfo.properties.push(propertie);
					// console.log(tplInfo.properties)
				}
				// console.log(tplInfo.properties);
			// 3.将完整一套模板存入数据
			tpl.data.push(tplInfo);
				// console.log(tplInfo);
				console.log(tpl.data);
			$scope.close();
		}
		$scope.save2=function(evt){		
			// console.log(tpl.data);	
			// 获取模板名称并加入
				// var tplIName=$($("#tplName")).val();
			// 获取模板属性并加入
				// 创建属性对象
				var temp_propertie=tpl.propertie;
				// 创建模板属性池
				var properties=tpl.arr_properties;
			// 新建模板
			var tplInfo=tpl.tplInfo;
				console.log(tplInfo);
				// 模板名称
				tplInfo.name=$($("#tplName")).val();
				// 模板属性池
				for(var i=0;i<$("input:checked").length;i++){
					temp_propertie.name=$($("input:checked")[i]).val();
					properties.push(temp_propertie.name);
					console.log(properties);
					console.log(tplInfo.name);
				}
				tpl.arr_properties=properties;
				console.log(properties);
				// 赋值模板
				tplInfo.properties=properties;
				console.log(tplInfo);
			// 存入数据
			tpl.data.push(tplInfo);
			console.log(tpl.data);
				


		}

		// $(window).keyDown(function(event){
		// 	alert(event.keyCode);
		// })
		// $scope.test={
		// 	hy:"234"}
		// $http.get("model/test.json").success(function(data){
		// 	$scope.hy=data;
		// })
		// $http.post("http://127.0.0.1/tsfintech/model/test.json",$scope.test)
		// 	.success(function(data){

		// 	})
		// 	.error(function(data){alert(data)})
	}])
	.controller('addProperties', ['$scope','$http','tpl', function($scope,$http,tpl){
		$scope.properties=tpl.properties;
		$scope.add=function(evt){
			tpl.properties.push($("#tplProperties").val())
			console.log(tpl.properties);
		}

		
	}])
	.controller('detail', ['$scope','$http','tpl', function($scope,$http,tpl){
		$scope.data=tpl.data;
		$scope.selectTpl;//选中项
		$scope.properties;//选中项属性
		$scope.tplChange=function(){
			console.log($scope.selectTpl);
		}
		$scope.save=function(){
			// $scope.selectTpl.properties.value=
			console.log($scope.selectTpl.properties.value);
		}

		
	}])
		// $scope.data="Hello World!"
		