/**
* services Module
*
* Description
*/
angular.module('services', [])
	.service('tpl', function(){
		this.propertie={
          "id": "",
          "name": "",
          "displayName": "",
          "type": {
             "id": ""
          },
          "viewWidget": {
            "id": "",
            "customized": { }
          },
          "editWidget": {
            "id": "",
            "customized": { }
          },
          "listWidget": {
            "id": "",
            "customized": { }
          }
        }
        this.arr_properties=[]
        this.tplInfo={	
        		"id": 1,
        	 	"name": "student",
        	 	"displayName": "学生",
        	 	"viewWidget": {
        	 		"id": "12",
        	 		"customized": { }
        	 	},
        	 	"editWidget": {
        	 		"id": "12",
        	 		"customized": { }
        	 	},
        	 	"listWidget": {
        	 		"id": "12",
        	 		"customized": { }
        	 	},
        	 	"properties":[]
        	}
        this.data=[this.tplInfo];
		// this.data.push(tpl.tplInfo);
		this.data2={
			"success":1,
			"errorMsg":"",
			"data":[{
					"id":" ",
					"name": "",
				//显示名称
					"displayName": "",
				// 视图控件
					"viewWidget": {
						"id": "12",
						 "customized": { }
					},
				// 编辑组件
					"editWidget": {
						"id": "12",
						// 定制
						 "customized": { }
					},
				// 列表组件
					"listWidget": {
						"id": "12",
						"customized": { }
					},
				// 属性
					"properties": [
						{
						    "id": "1",
						    "name": "近三年及当期的诉讼和仲裁情况",
						    "displayName": "",
						    "type": {
						             "id": ""
						    },
						    "viewWidget": {
						            "id": "12",
						            "customized": { }
						    },
						    "editWidget": {
						            "id": "12",
						            "customized": { }
						    },
						    "listWidget": {
						            "id": "12",
						            "customized": { }
						    }
						},
						{
						    "id": "2",
						    "name": "组织机构代码证",
						    "displayName": "",
						    "type": {
						             "id": ""
						    },
						    "viewWidget": {
						            "id": "12",
						            "customized": { }
						    },
						    "editWidget": {
						            "id": "12",
						            "customized": { }
						    },
						    "listWidget": {
						            "id": "12",
						            "customized": { }
						    }
						},
						{
						    "id": "3",
						    "name": "企业法人营业执照",
						    "displayName": "",
						    "type": {
						             "id": ""
						    },
						    "viewWidget": {
						            "id": "12",
						            "customized": { }
						    },
						    "editWidget": {
						            "id": "12",
						            "customized": { }
						    },
						    "listWidget": {
						            "id": "12",
						            "customized": { }
						    }
						},
						{
						    "id": "4",
						    "name": "相关准入资质或批复文件",
						    "displayName": "",
						    "type": {
						             "id": ""
						    },
						    "viewWidget": {
						            "id": "12",
						            "customized": { }
						    },
						    "editWidget": {
						            "id": "12",
						            "customized": { }
						    },
						    "listWidget": {
						            "id": "12",
						            "customized": { }
						    }
						},
						{
						    "id": "5",
						    "name": "相关权力机构通过的决议",
						    "displayName": "",
						    "type": {
						             "id": ""
						    },
						    "viewWidget": {
						            "id": "12",
						            "customized": { }
						    },
						    "editWidget": {
						            "id": "12",
						            "customized": { }
						    },
						    "listWidget": {
						            "id": "12",
						            "customized": { }
						    }
						},
						{
						    "id": "6",
						    "name": "行业特征/法规/政策",
						    "displayName": "",
						    "type": {
						             "id": ""
						    },
						    "viewWidget": {
						            "id": "12",
						            "customized": { }
						    },
						    "editWidget": {
						            "id": "12",
						            "customized": { }
						    },
						    "listWidget": {
						            "id": "12",
						            "customized": { }
						    }
						},
						{
						    "id": "7",
						    "name": "企业法人年检证明",
						    "displayName": "",
						    "type": {
						             "id": ""
						    },
						    "viewWidget": {
						            "id": "12",
						            "customized": { }
						    },
						    "editWidget": {
						            "id": "12",
						            "customized": { }
						    },
						    "listWidget": {
						            "id": "12",
						            "customized": { }
						    }
						},
						{
						    "id": "8",
						    "name": "企业信用信息报告",
						    "displayName": "",
						    "type": {
						             "id": ""
						    },
						    "viewWidget": {
						            "id": "12",
						            "customized": { }
						    },
						    "editWidget": {
						            "id": "12",
						            "customized": { }
						    },
						    "listWidget": {
						            "id": "12",
						            "customized": { }
						    }
						},
						{
						    "id": "9",
						    "name": "年检合格的税务登记证",
						    "displayName": "",
						    "type": {
						             "id": ""
						    },
						    "viewWidget": {
						            "id": "12",
						            "customized": { }
						    },
						    "editWidget": {
						            "id": "12",
						            "customized": { }
						    },
						    "listWidget": {
						            "id": "12",
						            "customized": { }
						    }
						},
						{
						    "id": "10",
						    "name": "法定代表人简历",
						    "displayName": "",
						    "type": {
						             "id": ""
						    },
						    "viewWidget": {
						            "id": "12",
						            "customized": { }
						    },
						    "editWidget": {
						            "id": "12",
						            "customized": { }
						    },
						    "listWidget": {
						            "id": "12",
						            "customized": { }
						    }
						},
						{
						    "id": "11",
						    "name": "股权结构及其与贷款服务商的关系",
						    "displayName": "",
						    "type": {
						             "id": ""
						    },
						    "viewWidget": {
						            "id": "12",
						            "customized": { }
						    },
						    "editWidget": {
						            "id": "12",
						            "customized": { }
						    },
						    "listWidget": {
						            "id": "12",
						            "customized": { }
						    }
						},
						{	
						    "id": "12",
						    "name": "法定代表人身份证明",
						    "displayName": "",
						    "type": {
						             "id": ""
						    },
						    "viewWidget": {
						            "id": "12",
						            "customized": { }
						    },
						    "editWidget": {
						            "id": "12",
						            "customized": { }
						    },
						    "listWidget": {
						            "id": "12",
						            "customized": { }
						    }
						},
						{	
						    "id": "13",
						    "name": "对于资金来源合法性的承诺",
						    "displayName": "",
						    "type": {
						             "id": ""
						    },
						    "viewWidget": {
						            "id": "12",
						            "customized": { }
						    },
						    "editWidget": {
						            "id": "12",
						            "customized": { }
						    },
						    "listWidget": {
						            "id": "12",
						            "customized": { }
						    }
						},
						{	
						    "id": "14",
						    "name": "其他必要的资料",
						    "displayName": "",
						    "type": {
						             "id": ""
						    },
						    "viewWidget": {
						            "id": "12",
						            "customized": { }
						    },
						    "editWidget": {
						            "id": "12",
						            "customized": { }
						    },
						    "listWidget": {
						            "id": "12",
						            "customized": { }
						    }
						},
						{	
						    "id": "15",
						    "name": "验资报告",
						    "displayName": "",
						    "type": {
						             "id": ""
						    },
						    "viewWidget": {
						            "id": "12",
						            "customized": { }
						    },
						    "editWidget": {
						            "id": "12",
						            "customized": { }
						    },
						    "listWidget": {
						            "id": "12",
						            "customized": { }
						    }
						}
					]
			}]
		}
		this.tplName={
			"id":1,
			"name":"",
			"properties":[
				{
					"name":[]
					// "value":""
				}
			]
		}
		this.properties=[
			"近三年及当期的诉讼和仲裁情况",
			"相关权力机构通过的决议",
			"行业特征/法规/政策",
			"企业法人年检证明",
			"相关准入资质或批复文件",
			"企业信用信息报告",
			"组织机构代码证",
			"企业法人营业执照",
			"法定代表人简历",
			"对于资金来源合法性的承诺",
			"年检合格的税务登记证",
			"股权结构及其与贷款服务商的关系",
			"法定代表人身份证明",
			"其他必要的资料",
			"验资报告"
		]

	})
